// Copier dans Arduino/libraries/TFT_eSPI/User_Setup_Select.h
// Commenter #include <User_Setup.h>
// Décommenter la ligne :

#include <User_Setups/Setup206_LilyGo_T_Display_S3.h>
