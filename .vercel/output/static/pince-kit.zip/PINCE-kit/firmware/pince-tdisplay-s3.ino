// PINCE — LilyGO T-Display S3 (ESP32-S3, ST7789 170×320)
// Arduino : ESP32S3 Dev Module · USB CDC On Boot Enabled · OPI PSRAM · Flash 16MB
// TFT_eSPI : User_Setup_Select.h → Setup206_LilyGo_T_Display_S3.h
// Libs : TFT_eSPI, ESP32Servo, ArduinoJson, WebSockets by Markus Sattler
//
// Header P2 (gauche) :
//   GPIO1 base · GPIO2 épaule · GPIO3 coude · GPIO10 poignet · GPIO11 pince
//   GPIO12 TRIG · GPIO13 ECHO · GND commun · 5V = VBUS USB (ne pas y brancher les servos)
// Alim servos : 5 V 3 A EXTERNE + GND commun.
// GPIO15 = POWER_ON écran — le firmware le met à HIGH.
// BTN2 (GPIO14) court = home · long = stop
// Wi-Fi AP : PINCE / pince1234 · ws://192.168.4.1:81
// JSON {"t":"pose","j":{"base":90,"shoulder":118,"elbow":48,"wrist":108,"grip":72},"spd":0.6}

#include <WiFi.h>
#include <WebSocketsServer.h>
#include <ESP32Servo.h>
#include <ArduinoJson.h>
#include <TFT_eSPI.h>

#define PIN_POWER 15
#define PIN_BTN2  14
#define PIN_BATT  4
#define PIN_TRIG  12
#define PIN_ECHO  13

const int SERVO_PIN[5] = {1, 2, 3, 10, 11};
const char* KEYS[5] = {"base","shoulder","elbow","wrist","grip"};
const char* LABELS[5] = {"BASE","EPAU","COUDE","POIG","PINCE"};
const int SMAX[5] = {180,180,180,180,90};

const char* AP_SSID = "PINCE";
const char* AP_PASS = "pince1234";

TFT_eSPI tft;
Servo srv[5];
WebSocketsServer ws(81);

float cur[5] = {90, 118, 48, 108, 72};
float tgt[5] = {90, 118, 48, 108, 72};
float spd = 0.6f;
uint32_t lastDraw = 0, lastBtn = 0, pressAt = 0;
bool pressed = false;
int clients = 0;

int clampi(int v, int a, int b){ return v < a ? a : (v > b ? b : v); }

void applyPose() {
  for (int i = 0; i < 5; i++) {
    cur[i] += (tgt[i] - cur[i]) * (0.08f + 0.28f * spd);
    srv[i].write(clampi((int)(cur[i] + 0.5f), 0, SMAX[i]));
  }
}

float usCm() {
  digitalWrite(PIN_TRIG, LOW); delayMicroseconds(2);
  digitalWrite(PIN_TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);
  long d = pulseIn(PIN_ECHO, HIGH, 18000);
  if (!d) return -1;
  return d / 58.0f;
}

float battV() {
  // Pont diviseur LilyGO sur GPIO4
  return analogReadMilliVolts(PIN_BATT) * 2.0f / 1000.0f;
}

void sendState(uint8_t n) {
  StaticJsonDocument<256> doc;
  doc["t"] = "state";
  JsonObject j = doc.createNestedObject("j");
  for (int i = 0; i < 5; i++) j[KEYS[i]] = (int)cur[i];
  doc["us"] = usCm();
  doc["v"] = battV();
  String s; serializeJson(doc, s);
  ws.sendTXT(n, s);
}

void onWs(uint8_t n, WStype_t type, uint8_t * payload, size_t length) {
  if (type == WStype_CONNECTED) { clients++; return; }
  if (type == WStype_DISCONNECTED) { clients = max(0, clients - 1); return; }
  if (type != WStype_TEXT) return;
  StaticJsonDocument<384> doc;
  if (deserializeJson(doc, payload, length)) return;
  const char* t = doc["t"] | "";
  if (!strcmp(t, "ping")) { sendState(n); return; }
  if (!strcmp(t, "stop") || !strcmp(t, "home")) {
    if (!strcmp(t, "home")) {
      const float h[5] = {90, 118, 48, 108, 72};
      for (int i = 0; i < 5; i++) tgt[i] = h[i];
    } else {
      for (int i = 0; i < 5; i++) tgt[i] = cur[i];
    }
    return;
  }
  if (!strcmp(t, "pose")) {
    JsonObject j = doc["j"];
    for (int i = 0; i < 5; i++) if (j.containsKey(KEYS[i])) tgt[i] = j[KEYS[i]];
    if (doc.containsKey("spd")) spd = doc["spd"];
  }
}

void drawUi() {
  const uint16_t BG = 0x1082, FG = 0xE73B, MUT = 0x8C71, ACC = 0xC616, OK = 0x8DE9;
  static bool chrome = false;
  static int lastBar[5] = {-1,-1,-1,-1,-1};
  static int lastUs = -999;
  static int lastCli = -1;
  if (!chrome) {
    tft.fillScreen(BG);
    tft.setTextDatum(TL_DATUM);
    tft.setTextColor(ACC, BG);
    tft.drawString("PINCE", 8, 6, 2);
    tft.setTextColor(MUT, BG);
    tft.drawString("T-DISPLAY S3", 70, 10, 1);
    for (int i = 0; i < 5; i++) {
      int y = 28 + i * 22;
      tft.setTextDatum(TL_DATUM);
      tft.setTextColor(MUT, BG);
      tft.drawString(LABELS[i], 8, y, 1);
    }
    tft.setTextColor(MUT, BG);
    tft.drawString("BTN2 home", 220, 144, 1);
    chrome = true;
  }
  char buf[24];
  snprintf(buf, sizeof(buf), "%.2fV", battV());
  tft.setTextDatum(TR_DATUM);
  tft.setTextColor(OK, BG);
  tft.drawString(buf, 312, 8, 1);

  for (int i = 0; i < 5; i++) {
    int w = (int)(200.0f * cur[i] / SMAX[i]);
    if (w == lastBar[i]) continue;
    lastBar[i] = w;
    int y = 28 + i * 22;
    tft.fillRect(56, y + 2, 200, 10, 0x2104);
    tft.fillRect(56, y + 2, w, 10, ACC);
    snprintf(buf, sizeof(buf), "%3d", (int)cur[i]);
    tft.setTextDatum(TR_DATUM);
    tft.setTextColor(FG, BG);
    tft.drawString(buf, 312, y, 1);
  }

  float d = usCm();
  int di = (int)(d * 10);
  if (di != lastUs || clients != lastCli) {
    lastUs = di; lastCli = clients;
    tft.fillRect(8, 142, 200, 16, BG);
    tft.setTextDatum(TL_DATUM);
    tft.setTextColor(MUT, BG);
    if (d < 0) tft.drawString("US --", 8, 144, 1);
    else {
      snprintf(buf, sizeof(buf), "US %.1f cm", d);
      tft.drawString(buf, 8, 144, 1);
    }
    tft.setTextColor(clients ? OK : MUT, BG);
    tft.drawString(clients ? "WS ON" : "AP PINCE", 120, 144, 1);
  }
}

void handleBtn() {
  bool down = digitalRead(PIN_BTN2) == LOW;
  uint32_t now = millis();
  if (down && !pressed) { pressed = true; pressAt = now; }
  if (!down && pressed) {
    pressed = false;
    uint32_t dt = now - pressAt;
    if (dt > 50 && dt < 700) {
      const float h[5] = {90, 118, 48, 108, 72};
      for (int i = 0; i < 5; i++) tgt[i] = h[i];
    } else if (dt >= 700) {
      for (int i = 0; i < 5; i++) tgt[i] = cur[i];
    }
  }
}

void setup() {
  pinMode(PIN_POWER, OUTPUT);
  digitalWrite(PIN_POWER, HIGH); // obligatoire : alimente LCD + periphs
  pinMode(PIN_BTN2, INPUT_PULLUP);
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);
  analogReadResolution(12);

  Serial.begin(115200);
  delay(150);
  tft.init();
  tft.setRotation(1); // 320 × 170
  tft.fillScreen(0x1082);

  for (int i = 0; i < 5; i++) {
    srv[i].setPeriodHertz(50);
    srv[i].attach(SERVO_PIN[i], 500, 2500);
    srv[i].write((int)cur[i]);
  }

  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS);
  ws.begin();
  ws.onEvent(onWs);
  Serial.println(WiFi.softAPIP());
  drawUi();
}

void loop() {
  ws.loop();
  applyPose();
  handleBtn();
  if (millis() - lastDraw > 180) {
    lastDraw = millis();
    drawUi();
  }
  delay(8);
}
