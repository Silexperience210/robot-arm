// PINCE — pack imprimable 5 DDL + pince + berceau LilyGO T-Display S3
// OpenSCAD · F6 → STL · mm · 0.2 mm, 3 parois, 25–30 % infill, PLA/PETG

$fn = 48;
sg90_body = [23.2, 12.4, 22.5];
sg90_flange = [32.2, 12.4, 2.6];
clear = 0.35;

module sg90_pocket() {
  cube(sg90_body + [clear, clear, 8], center=true);
  translate([0,0,sg90_body.z/2]) cube(sg90_flange + [clear, clear, 0], center=true);
}

module plate_base() {
  difference() {
    hull() {
      for (x=[-38,38], y=[-38,38]) translate([x,y,0]) cylinder(h=6, r=6);
    }
    for (a=[0,90,180,270]) rotate([0,0,a]) translate([32,32,-1]) cylinder(h=10, d=3.3);
    translate([0,0,8]) sg90_pocket();
  }
}

module link(len=110, thick=8, wide=16) {
  difference() {
    union() {
      hull() {
        cylinder(h=thick, d=wide);
        translate([len,0,0]) cylinder(h=thick, d=wide-2);
      }
      translate([0,0,thick]) cylinder(h=4, d=7);
    }
    translate([0,0,-1]) cylinder(h=thick+8, d=2.2);
    translate([len,0,-1]) cylinder(h=thick+8, d=2.2);
    for (i=[1:4]) rotate([0,0,i*90]) translate([4.6,0,-1]) cylinder(h=6, d=1.4);
  }
}

module jaw() {
  difference() {
    union() {
      cube([8, 12, 36], center=true);
      translate([0,0,16]) cube([8, 18, 8], center=true);
      translate([5,0,-10]) cube([10, 3, 16], center=true);
    }
    translate([0,0,16]) rotate([90,0,0]) cylinder(h=20, d=2.2, center=true);
  }
}

module gripper_palm() {
  difference() {
    cube([34, 22, 14], center=true);
    translate([0,0,4]) cube([18, 14, 12], center=true);
    for (x=[-10,10]) translate([x,0,0]) rotate([90,0,0]) cylinder(h=30, d=2.2, center=true);
  }
}

// Berceau T-Display S3 — carte ~64 × 32 × 8, USB-C dégagé, boutons accessibles
module tdisplay_cradle() {
  difference() {
    rounded(70, 38, 10, 3);
    translate([3, 3, 3]) rounded(64, 32, 10, 2);
    translate([-1, 12, 4]) cube([8, 10, 8]); // USB-C
    translate([28, -1, 6]) cube([16, 6, 6]); // BTN2 / BOOT
  }
}

module cam_mount() {
  difference() {
    union() {
      cube([36, 10, 4]);
      translate([8, 10, 0]) cube([20, 18, 4]);
      translate([12, 22, 4]) cylinder(h=8, d=10);
    }
    translate([18, 28, -1]) cylinder(h=16, d=6.2); // objectif
    for (x=[4, 32]) translate([x, 5, -1]) cylinder(h=8, d=2.2);
  }
}

module rounded(x, y, z, r) {
  hull() {
    for (ix=[r, x-r], iy=[r, y-r]) translate([ix, iy, 0]) cylinder(h=z, r=r);
  }
}

module assembly() {
  plate_base();
  translate([0,0,28]) rotate([0,90,0]) link(120);
  translate([0,0,28]) rotate([0,90,35]) translate([120,0,0]) link(105);
  translate([90,40,8]) gripper_palm();
  translate([90,60,8]) jaw();
  translate([90,78,8]) mirror([1,0,0]) jaw();
  translate([-90, -20, 0]) tdisplay_cradle();
  translate([40, -50, 0]) cam_mount();
}

assembly();
