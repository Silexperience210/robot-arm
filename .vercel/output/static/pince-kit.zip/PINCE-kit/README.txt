PINCE — kit bras robotique 5 DDL
================================
LilyGO T-Display S3 + 5× servo 9g + ESP32-CAM + HC-SR04

1. Imprime le dossier stl/  (voir PRINT.txt)
2. Flash firmware/  (voir FLASH.txt)
3. Câble selon CABLAGE.txt
4. Ouvre le studio PINCE sur le téléphone, Wi-Fi PINCE / pince1234

Contenu
-------
stl/          pièces prêtes à slicer (mm)
scad/         source OpenSCAD si tu veux modifier
firmware/     T-Display S3 + ESP32-CAM + setup TFT_eSPI
pi/           pont optionnel Raspberry Pi 4
BOM.txt       ce que tu as / ce qu'il manque
CABLAGE.txt   GPIO exacts T-Display S3
PRINT.txt     orientation, infill, quantités
FLASH.txt     Arduino pas à pas
